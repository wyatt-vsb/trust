# Economic Simulation for `wyatt-vsb/trust`

This package contains new simulator files and updated copies of four files from
the fork's `gh-pages` branch. It preserves the original guide, assets, license,
and credits.

Copy the contents of this package into the repository root, keeping the `css`
and `js` folders. Replace the four matching existing files when prompted.
In Replit, click **Run**, then open `economic-simulation.html` from the link on
the original guide or at `/economic-simulation.html` in Preview. Open Preview
in a full tab for more chart space; the original guide now scales down in
narrow previews as well.

Run `node --test js/economic-sim.test.mjs` to verify the model. The server is
the existing `npm start` command; no new package is needed.

The controls default to 25 players, 20 rounds per pair, 100 generations,
and five eliminations and reproductions per generation. The tax comparison
uses the same seed and starting population for all four scenarios.

The game is a model for exploring assumptions, not a real-world economic
forecast. Cooperation is measured from moves, independently of earnings.
