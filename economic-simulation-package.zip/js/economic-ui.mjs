import {run,compare,LABELS,STRATEGIES} from './economic-sim.mjs';
const $=id=>document.getElementById(id);
const colors={tft:'#4089dd',all_d:'#52537f',all_c:'#dd54c8',grudge:'#b59600',prober:'#ce7d23',tf2t:'#7c9bc5',pavlov:'#60a92a',random:'#e75b5b'};
const fmt=x=>Number(x).toFixed(1);
function settings(){const f=new FormData($('form'));const x=Object.fromEntries(f.entries());
  for(const key of Object.keys(x))x[key]=Number(x[key]);
  for(const key of ['flatTax','upperTax','noise'])x[key]/=100;
  return x;
}
function svgSeries(series,ymax,formatter){
  const width=760,height=250,left=48,right=14,top=12,bottom=35,w=width-left-right,h=height-top-bottom;
  const maxX=Math.max(1,...series.map(s=>s.values.length-1));
  const lines=series.map(s=>{const points=s.values.map((v,i)=>`${left+i/maxX*w},${top+h-Math.max(0,v)/ymax*h}`).join(' ');
    return `<polyline points="${points}" fill="none" stroke="${s.color}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>`;}).join('');
  const grid=[0,.25,.5,.75,1].map(q=>`<line x1="${left}" y1="${top+h-q*h}" x2="${left+w}" y2="${top+h-q*h}" stroke="#dce3e8"/><text x="${left-7}" y="${top+h-q*h+4}" text-anchor="end">${formatter(q*ymax)}</text>`).join('');
  return `<svg class="chart" viewBox="0 0 ${width} ${height}" role="img" aria-label="Trend over generations">${grid}${lines}<text x="${left}" y="${height-7}">1</text><text x="${left+w}" y="${height-7}" text-anchor="end">${maxX+1} generations</text></svg>`;
}
function legend(items){return items.map(x=>`<span><i style="background:${x.color}"></i>${x.name}</span>`).join('');}
function metric(label,value){return `<div class="metric"><b>${value}</b><span>${label}</span></div>`;}
function status(i,detail,kind){const list=kind==='raw'?[detail.rawBottom,detail.rawTop]:[detail.netBottom,detail.netTop];
  return list[0].includes(i)?'<span class="tag out">Out</span>':list[1].includes(i)?'<span class="tag in">Parent</span>':'—';}
function render(result,title){
  const {history,lastGeneration:d,config}=result,last=history.at(-1);
  $('resultTitle').textContent=title;
  $('metrics').innerHTML=metric('Cooperation',`${fmt(last.cooperation*100)}%`)+metric('Game output',fmt(last.productivity))+
    metric('Selection reversals, bottom / top',`${last.reversalBottom} / ${last.reversalTop}`)+metric('Active payoff opportunities',`${fmt(last.participation*100)}%`);
  $('note').textContent=`${config.population} players · ${config.rounds} rounds per pair · ${config.generations} generations · seed ${config.seed}. Last-generation tax pool ${fmt(d.pool)}; benefit funding ${fmt(d.benefitScale*100)}%.`;
  const trends=[{name:'Cooperation',color:'#1680a0',values:history.map(h=>h.cooperation*100)},
    {name:'Participation',color:'#ae6b22',values:history.map(h=>h.participation*100)}];
  $('trendLegend').innerHTML=legend(trends);
  $('trend').innerHTML=svgSeries(trends,100,x=>`${Math.round(x)}%`)+`<p class="hint">Game output (last generation): ${fmt(last.productivity)}. Cooperation counts actual moves; participation counts earned payoff opportunities.</p>`;
  const survivors=STRATEGIES.map(s=>({name:LABELS[s],color:colors[s],values:history.map(h=>h.counts[s])}));
  $('survivalLegend').innerHTML=legend(survivors);
  $('survival').innerHTML=svgSeries(survivors,config.population,x=>Math.round(x));
  $('players').innerHTML=d.population.map((s,i)=>`<tr><td>${i+1}. ${LABELS[s]}</td><td>${fmt(d.cooperation[i]*100)}%</td><td>${fmt(d.earnings[i])}</td><td>${fmt(d.taxes[i])}</td><td>${fmt(d.benefits[i])}</td><td>${fmt(d.net[i])}</td><td>${status(i,d,'raw')}</td><td>${status(i,d,'net')}</td></tr>`).join('');
}
function renderComparison(results){
  const series=results.map(({rate,run:r},i)=>({name:`${Math.round(rate*100)}% base tax`,color:['#52537f','#4089dd','#e59a28','#d35050'][i],values:r.history.map(h=>h.cooperation*100)}));
  const output=results.map(({rate,run:r},i)=>({name:series[i].name,color:series[i].color,values:r.history.map(h=>h.productivity)}));
  const reversals=results.map(({rate,run:r},i)=>({name:series[i].name,color:series[i].color,values:r.history.map(h=>h.reversalBottom)}));
  $('resultTitle').textContent='Tax comparison';$('trendLegend').innerHTML=legend(series);
  $('trend').innerHTML=svgSeries(series,100,x=>`${Math.round(x)}%`)+`<h2>Game output</h2>${svgSeries(output,Math.max(1,...output.flatMap(s=>s.values)),x=>Math.round(x))}<h2>Bottom-five selection reversals</h2>${svgSeries(reversals,results[0].run.config.selection,x=>Math.round(x))}`;
  $('survivalLegend').innerHTML=legend(series);
  $('survival').innerHTML=svgSeries(results.map((x,i)=>({...series[i],values:x.run.history.map(h=>h.counts.all_c+h.counts.tft+h.counts.grudge+h.counts.tf2t)})),results[0].run.config.population,x=>Math.round(x))+
    '<p class="hint">Count of Always Cooperate, Copycat, Grudger and Copykitten. This grouping describes strategy names, not each player’s actual moves.</p>';
  const rows=results.map(({rate,run:r})=>{const h=r.history.at(-1);return `${Math.round(rate*100)}%: cooperation ${fmt(h.cooperation*100)}%, output ${fmt(h.productivity)}, bottom reversals ${h.reversalBottom}`;});
  $('metrics').innerHTML=rows.map((row,i)=>metric(series[i].name,row.split(': ')[1])).join('');
  $('note').textContent='Scenarios use the same seed and starting population. With effort response at 0, tax changes selection but has no direct effect on within-game behavior.';
  renderTable(results[0].run.lastGeneration);
}
function renderTable(d){$('players').innerHTML=d.population.map((s,i)=>`<tr><td>${i+1}. ${LABELS[s]}</td><td>${fmt(d.cooperation[i]*100)}%</td><td>${fmt(d.earnings[i])}</td><td>${fmt(d.taxes[i])}</td><td>${fmt(d.benefits[i])}</td><td>${fmt(d.net[i])}</td><td>${status(i,d,'raw')}</td><td>${status(i,d,'net')}</td></tr>`).join('');}
function handle(fn){try{$('error').textContent='';fn();}catch(e){$('error').textContent=e.message;}}
$('form').addEventListener('submit',e=>{e.preventDefault();handle(()=>render(run(settings()),'Single run'));});
$('compare').addEventListener('click',()=>handle(()=>renderComparison(compare({...settings(),upperTax:0},[0,.1,.25,.5]))));
handle(()=>render(run(settings()),'Single run'));
