import test from 'node:test';
import assert from 'node:assert/strict';
import {run,transfer,compare} from './economic-sim.mjs';

test('seed repeats the complete experiment and preserves population',()=>{
  const a=run({generations:5}),b=run({generations:5});
  assert.deepEqual(a,b);assert.equal(a.finalPopulation.length,25);
});
test('balanced budget and zero-tax selection',()=>{
  const x=transfer([0,10,20],{population:25,flatTax:.2,benefit:5,benefitCutoff:15});
  assert.ok(Math.abs(x.net.reduce((a,b)=>a+b,0)-30)<1e-9);
  const r=run({generations:2});
  assert.ok(r.history.every(h=>h.reversalBottom===0 && h.reversalTop===0));
});
test('cliff can reverse ranking without inferring strategy from earnings',()=>{
  const x=transfer([49,50],{flatTax:.5,benefit:20,benefitCutoff:50});
  assert.ok(x.net[0]>x.net[1]);
});
test('comparison shares starting conditions and varies rates',()=>{
  const x=compare({generations:2});assert.equal(x.length,4);
  assert.deepEqual(x[0].run.lastGeneration.population,run({generations:2}).lastGeneration.population);
  assert.equal(x[0].run.config.flatTax,0);assert.equal(x[3].run.config.flatTax,.5);
});
