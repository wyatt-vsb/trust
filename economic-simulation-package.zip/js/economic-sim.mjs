// Independent, seeded extension of Nicky Case's Evolution of Trust.
export const STRATEGIES = ['tft', 'all_d', 'all_c', 'grudge', 'prober', 'tf2t', 'pavlov', 'random'];
export const DEFAULTS = {population:25, rounds:20, generations:100, selection:5, seed:12345,
  flatTax:0, upperTax:0, upperThreshold:480, benefit:0, benefitCutoff:240,
  benefitTaper:0, effortResponse:0, noise:0, payoff:{P:0,S:-1,R:2,T:3}};
export const LABELS = {tft:'Copycat',all_d:'Always Cheat',all_c:'Always Cooperate',grudge:'Grudger',
  prober:'Detective',tf2t:'Copykitten',pavlov:'Simpleton',random:'Random'};

function rng(seed) {
  let state = seed >>> 0;
  return () => { state = (state + 0x6D2B79F5) >>> 0; let t = state;
    t = Math.imul(t ^ t >>> 15, t | 1); t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296; };
}
const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
function number(value, lo, hi, name) {
  const n = Number(value); if (!Number.isFinite(n) || n < lo || n > hi) throw Error(`${name} must be between ${lo} and ${hi}`);
  return n;
}
export function normalize(input={}) {
  const o={...DEFAULTS,...input,payoff:{...DEFAULTS.payoff,...input.payoff}};
  o.population=number(o.population,10,200,'Population');
  o.rounds=number(o.rounds,1,100,'Rounds'); o.generations=number(o.generations,1,500,'Generations');
  o.selection=number(o.selection,1,Math.floor(o.population/2),'Selection count');
  for (const key of ['population','rounds','generations','selection','seed']) if (!Number.isInteger(o[key])) throw Error(`${key} must be an integer`);
  o.flatTax=number(o.flatTax,0,1,'Base tax'); o.upperTax=number(o.upperTax,0,1,'Upper tax');
  if(o.flatTax+o.upperTax>1) throw Error('Combined tax rate cannot exceed 100%');
  o.upperThreshold=number(o.upperThreshold,0,100000,'Upper threshold');
  o.benefit=number(o.benefit,0,100000,'Benefit'); o.benefitCutoff=number(o.benefitCutoff,0,100000,'Benefit cutoff');
  o.benefitTaper=number(o.benefitTaper,0,10,'Benefit taper');
  o.effortResponse=number(o.effortResponse,0,1,'Effort response'); o.noise=number(o.noise,0,1,'Noise');
  for(const key of ['P','S','R','T']) o.payoff[key]=number(o.payoff[key],-100,100,`Payoff ${key}`);
  return o;
}
export function initialPopulation(count) {
  return Array.from({length:count},(_,i)=>STRATEGIES[i%STRATEGIES.length]);
}
function logic(strategy, random) {
  let lastOther=true, lastOwn=true, cheated=0, grudge=false, probe=0, retaliated=false;
  return {
    move(){switch(strategy){
      case 'tft':return lastOther; case 'all_d':return false; case 'all_c':return true;
      case 'grudge':return !grudge; case 'tf2t':return cheated<2;
      case 'pavlov':return lastOther ? lastOwn : !lastOwn;
      case 'random':return random()<0.5;
      case 'prober':return probe<4 ? [true,false,true,true][probe] : retaliated ? lastOther : false;
    }},
    remember(own,other){if(strategy==='prober' && probe>0 && probe<4 && !other) retaliated=true;
      probe++; lastOwn=own; lastOther=other; cheated=other?0:cheated+1; if(!other) grudge=true;}
  };
}
export function transfer(earnings, config) {
  const c=normalize(config), taxes=earnings.map(x=>Math.max(0,x)*c.flatTax + Math.max(0,x-c.upperThreshold)*c.upperTax);
  const pool=taxes.reduce((a,b)=>a+b,0);
  // Requested benefit schedule is scaled to the available tax pool. Unspent funds are rebated equally.
  const requests=earnings.map(x=>c.benefit===0 || x>=c.benefitCutoff ? 0 :
    c.benefitTaper===0 ? c.benefit : clamp(c.benefit-c.benefitTaper*Math.max(0,x),0,c.benefit));
  const requested=requests.reduce((a,b)=>a+b,0), scale=requested>pool ? pool/requested : 1;
  const residual=(pool-requested*scale)/earnings.length;
  const benefits=requests.map(x=>x*scale+residual);
  const net=earnings.map((x,i)=>x-taxes[i]+benefits[i]);
  return {taxes,benefits,net,pool,benefitScale:scale};
}
function rank(scores, ties){return scores.map((score,i)=>({i,score,tie:ties[i]})).sort((a,b)=>a.score-b.score || a.tie-b.tie).map(x=>x.i);}
function oneGeneration(population,c,random) {
  const n=population.length, earnings=Array(n).fill(0), actions=Array(n).fill(0), opportunities=Array(n).fill(0);
  let grossOutput=0, cooperations=0, moves=0, effort=0;
  for(let a=0;a<n;a++) for(let b=a+1;b<n;b++) {
    const A=logic(population[a],random),B=logic(population[b],random);
    for(let turn=0;turn<c.rounds;turn++) {
      // Optional effort response is explicit behavior, independent of strategy and income rank.
      const taxSignal=clamp(c.flatTax+c.upperTax,0,1);
      const participate=1-c.effortResponse*taxSignal;
      const activeA=random()<participate, activeB=random()<participate;
      let mA=A.move(),mB=B.move();
      if(random()<c.noise)mA=!mA; if(random()<c.noise)mB=!mB;
      A.remember(mA,mB);B.remember(mB,mA);
      const pA=mA?(mB?c.payoff.R:c.payoff.S):(mB?c.payoff.T:c.payoff.P);
      const pB=mB?(mA?c.payoff.R:c.payoff.T):(mA?c.payoff.S:c.payoff.P);
      earnings[a]+=activeA?pA:0; earnings[b]+=activeB?pB:0;
      grossOutput+=Math.max(0,(activeA?pA:0)+(activeB?pB:0));
      cooperations+=Number(mA)+Number(mB); moves+=2; effort+=Number(activeA)+Number(activeB);
      actions[a]+=Number(mA);actions[b]+=Number(mB);opportunities[a]++;opportunities[b]++;
    }
  }
  const ties=earnings.map(()=>random());
  const fiscal=transfer(earnings,c), rawRank=rank(earnings,ties), netRank=rank(fiscal.net,ties);
  const rawBottom=rawRank.slice(0,c.selection),netBottom=netRank.slice(0,c.selection);
  const rawTop=rawRank.slice(-c.selection),netTop=netRank.slice(-c.selection);
  const reversalBottom=netBottom.filter(i=>!rawBottom.includes(i)).length;
  const reversalTop=netTop.filter(i=>!rawTop.includes(i)).length;
  const next=population.filter((_,i)=>!netBottom.includes(i)).concat(netTop.map(i=>population[i]));
  const counts=Object.fromEntries(STRATEGIES.map(s=>[s,next.filter(x=>x===s).length]));
  return {next,summary:{cooperation:cooperations/moves,productivity:grossOutput,meanEarnings:earnings.reduce((a,b)=>a+b,0)/n,
    participation:effort/moves,reversalBottom,reversalTop,counts},
    detail:{population:population.slice(),earnings,cooperation:actions.map((x,i)=>x/opportunities[i]),...fiscal,
      rawBottom,rawTop,netBottom,netTop}};
}
export function run(input={}) {
  const c=normalize(input),random=rng(c.seed),history=[];
  let population=input.initial ? input.initial.slice() : initialPopulation(c.population);
  if(population.length!==c.population || population.some(x=>!STRATEGIES.includes(x))) throw Error('Initial population must contain valid strategies');
  let detail;
  for(let generation=1;generation<=c.generations;generation++) {
    const result=oneGeneration(population,c,random); population=result.next;detail=result.detail;
    history.push({generation,...result.summary});
  }
  return {config:c,history,finalPopulation:population,lastGeneration:detail};
}
export function compare(input={},rates=[0,0.1,0.25,0.5]) {
  return rates.map(rate=>({rate,run:run({...input,flatTax:rate})}));
}
